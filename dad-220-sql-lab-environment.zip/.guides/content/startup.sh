#!/bin/bash
sudo chmod -R a+rwx /home/codio/workspace
mysql




